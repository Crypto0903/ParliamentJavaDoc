
import java.util.ArrayList;
import java.util.List;
/**
 * The RajyaSabha class represents the upper house of the Parliament with attributes
 * such as chairman name and a list of members. It extends the Parliament class and
 * includes methods to manage the members and display information.
 * 
 * Author: Vignesh Sudhan Valvaikar
 * Roll no: 54
 * Start Date:
 * Modified Date: 23/07/2024
 */

public class RajyaSabha extends Parliament {
    private String chairmanName;
    private List<MP> members;

    /**
     * Constructs a RajyaSabha object with the specified number of members and chairman name.
     * 
     * @param numberOfMembers the number of members in the Rajya Sabha
     * @param chairmanName the name of the chairman of the Rajya Sabha
     */
    public RajyaSabha(int numberOfMembers, String chairmanName) {
        super(numberOfMembers);
        this.chairmanName = chairmanName;
        this.members = new ArrayList<>();
    }

    /**
     * Returns the name of the chairman of the Rajya Sabha.
     * 
     * @return the name of the chairman of the Rajya Sabha
     */
    public String getChairmanName() {
        return chairmanName;
    }

    /**
     * Sets the name of the chairman of the Rajya Sabha.
     * 
     * @param chairmanName the new name of the chairman of the Rajya Sabha
     */
    public void setChairmanName(String chairmanName) {
        this.chairmanName = chairmanName;
    }

    /**
     * Adds a member to the Rajya Sabha. If the Rajya Sabha is full, an appropriate message is displayed.
     * 
     * @param mp the Member of Parliament (MP) to be added
     */
    public void addMember(MP mp) {
        if (members.size() < getNumberOfMembers()) {  // Use getNumberOfMembers() to access the parent class variable
            members.add(mp);
        } else {
            System.out.println("Rajya Sabha is full.");
        }
    }

    /**
     * Displays the information about the Rajya Sabha, including the chairman and the list of members.
     */
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Rajya Sabha Chairman: " + chairmanName);
        System.out.println("Members:");
        for (MP mp : members) {
            mp.displayInfo();
        }
    }
}
