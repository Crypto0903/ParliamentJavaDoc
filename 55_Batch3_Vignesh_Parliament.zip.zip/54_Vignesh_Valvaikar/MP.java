/**
 * The MP class represents a Member of Parliament with attributes such as
 * name, constituency, and party affiliation.
 * 
 * Author: Vignesh Sudhan Valvaikar
 * Roll no: 54
 * Start Date:
 * Modified Date: 23/07/2024
 */
public class MP {
    private String name;
    private String constituency;
    private String party;

    /**
     * Constructs an MP object with the specified name, constituency, and party.
     * 
     * @param name the name of the MP
     * @param constituency the constituency of the MP
     * @param party the party affiliation of the MP
     */
    public MP(String name, String constituency, String party) {
        this.name = name;
        this.constituency = constituency;
        this.party = party;
    }

    /**
     * Returns the name of the MP.
     * 
     * @return the name of the MP
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the MP.
     * 
     * @param name the new name of the MP
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the constituency of the MP.
     * 
     * @return the constituency of the MP
     */
    public String getConstituency() {
        return constituency;
    }

    /**
     * Sets the constituency of the MP.
     * 
     * @param constituency the new constituency of the MP
     */
    public void setConstituency(String constituency) {
        this.constituency = constituency;
    }

    /**
     * Returns the party affiliation of the MP.
     * 
     * @return the party affiliation of the MP
     */
    public String getParty() {
        return party;
    }

    /**
     * Sets the party affiliation of the MP.
     * 
     * @param party the new party affiliation of the MP
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * Displays the information of the MP.
     */
    public void displayInfo() {
        System.out.println("MP Name: " + name);
        System.out.println("Constituency: " + constituency);
        System.out.println("Party: " + party);
    }
}
