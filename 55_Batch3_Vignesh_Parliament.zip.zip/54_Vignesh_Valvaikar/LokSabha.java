import java.util.ArrayList;
import java.util.List;

/**
 * The LokSabha class represents the lower house of the Parliament.
 * It extends the Parliament class and includes additional attributes
 * such as the speaker's name and a list of members.
 * 
 * Author: Vignesh Sudhan Valvaikar
 * Roll no: 54
 * Start Date:
 * Modified Date: 23/07/2024
 */
public class LokSabha extends Parliament {
    private String speakerName;
    private List<MP> members;

    /**
     * Constructs a LokSabha object with the specified number of members and speaker's name.
     * 
     * @param numberOfMembers the number of members in the Lok Sabha
     * @param speakerName the name of the speaker of the Lok Sabha
     */
    public LokSabha(int numberOfMembers, String speakerName) {
        super(numberOfMembers);
        this.speakerName = speakerName;
        this.members = new ArrayList<>();
    }

    /**
     * Returns the name of the speaker of the Lok Sabha.
     * 
     * @return the name of the speaker
     */
    public String getSpeakerName() {
        return speakerName;
    }

    /**
     * Sets the name of the speaker of the Lok Sabha.
     * 
     * @param speakerName the name of the speaker
     */
    public void setSpeakerName(String speakerName) {
        this.speakerName = speakerName;
    }

    /**
     * Adds a member to the Lok Sabha if there is space available.
     * 
     * @param mp the member of parliament to add
     */
    public void addMember(MP mp) {
        if (members.size() < getNumberOfMembers()) { // Use getNumberOfMembers() to access the parent class variable
            members.add(mp);
        } else {
            System.out.println("Lok Sabha is full.");
        }
    }

    /**
     * Displays the information about the Lok Sabha, including the speaker's name
     * and the details of all members.
     */
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Lok Sabha Speaker: " + speakerName);
        System.out.println("Members:");
        for (MP mp : members) {
            mp.displayInfo();
        }
    }
}
