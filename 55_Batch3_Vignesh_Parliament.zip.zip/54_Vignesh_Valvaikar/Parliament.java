/**
 * The Parliament class represents a legislative body in a country, specifically
 * India in this case. It includes attributes for the number of members and
 * methods to simulate parliamentary actions.
 * 
 * Author: Vignesh Sudhan Valvaikar
 * Roll no: 54
 * Start Date:
 * Modified Date: 23/07/2024
 */
public class Parliament {
    private static final String COUNTRY = "India";
    private int numberOfMembers;

    /**
     * Constructs a Parliament object with the specified number of members.
     * 
     * @param numberOfMembers the number of members in the Parliament
     */
    public Parliament(int numberOfMembers) {
        this.numberOfMembers = numberOfMembers;
    }

    /**
     * Returns the number of members in the Parliament.
     * 
     * @return the number of members in the Parliament
     */
    public int getNumberOfMembers() {
        return numberOfMembers;
    }

    /**
     * Sets the number of members in the Parliament.
     * 
     * @param numberOfMembers the new number of members in the Parliament
     */
    public void setNumberOfMembers(int numberOfMembers) {
        this.numberOfMembers = numberOfMembers;
    }

    /**
     * Displays the information about the Parliament, including the country and the number of members.
     */
    public void displayInfo() {
        System.out.println("Country: " + COUNTRY);
        System.out.println("Number of Members: " + numberOfMembers);
    }

    /**
     * Simulates the passing of a bill in the Parliament.
     * 
     * @param billName the name of the bill to be passed
     */
    public void passBill(String billName) {
        System.out.println("The bill '" + billName + "' has been passed by the Parliament.");
    }

    /**
     * Simulates a debate on a given topic in the Parliament.
     * 
     * @param topic the topic to be debated
     */
    public void debate(String topic) {
        System.out.println("Debate on the topic: " + topic + " is in progress in the Parliament.");
    }

    /**
     * Simulates the adjournment of a Parliament session.
     */
    public void adjournSession() {
        System.out.println("The Parliament session has been adjourned.");
    }
}
