/**
 * The President class represents the head of state with attributes such as name,
 * term start date, and term length. It includes methods to perform various
 * presidential actions.
 * 
 * Author: Vignesh Sudhan Valvaikar
 * Roll no: 54
 * Start Date:
 * Modified Date: 23/07/2024
 */
public class President {
    private String name;
    private String termStart;
    private int termLength;

    /**
     * Constructs a President object with the specified name, term start date, and term length.
     * 
     * @param name the name of the President
     * @param termStart the start date of the President's term
     * @param termLength the length of the President's term in years
     */
    public President(String name, String termStart, int termLength) {
        this.name = name;
        this.termStart = termStart;
        this.termLength = termLength;
    }

    /**
     * Returns the name of the President.
     * 
     * @return the name of the President
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the President.
     * 
     * @param name the new name of the President
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the start date of the President's term.
     * 
     * @return the start date of the President's term
     */
    public String getTermStart() {
        return termStart;
    }

    /**
     * Sets the start date of the President's term.
     * 
     * @param termStart the new start date of the President's term
     */
    public void setTermStart(String termStart) {
        this.termStart = termStart;
    }

    /**
     * Returns the length of the President's term in years.
     * 
     * @return the length of the President's term in years
     */
    public int getTermLength() {
        return termLength;
    }

    /**
     * Sets the length of the President's term in years.
     * 
     * @param termLength the new length of the President's term in years
     */
    public void setTermLength(int termLength) {
        this.termLength = termLength;
    }

    /**
     * Displays the information about the President.
     */
    public void displayInfo() {
        System.out.println("President: " + name);
        System.out.println("Term Start: " + termStart);
        System.out.println("Term Length: " + termLength + " years");
    }

    /**
     * Appoints the specified person as the Prime Minister.
     * 
     * @param primeMinisterName the name of the Prime Minister to be appointed
     */
    public void appointPrimeMinister(String primeMinisterName) {
        System.out.println("The President has appointed " + primeMinisterName + " as the Prime Minister.");
    }

    /**
     * Signs the specified bill into law.
     * 
     * @param billName the name of the bill to be signed into law
     */
    public void signBill(String billName) {
        System.out.println("The President has signed the bill '" + billName + "' into law.");
    }

    /**
     * Declares a state of emergency.
     */
    public void declareEmergency() {
        System.out.println("The President has declared a state of emergency.");
    }

    /**
     * Addresses the nation with the specified message.
     * 
     * @param message the message to be delivered to the nation
     */
    public void addressNation(String message) {
        System.out.println("The President's address to the nation: " + message);
    }
}
